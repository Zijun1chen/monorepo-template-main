ZijunPy

## Description


## Installation
```bash
pip install ZijunPy
